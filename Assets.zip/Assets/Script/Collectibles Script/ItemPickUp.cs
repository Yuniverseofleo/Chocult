using UnityEngine;

public enum ItemType
{
    RawCacaoBeans,
    CacaoPods,
    GroundCacao,
    Tablea,
    Tsokolate,
    PremiumChocolateBar
}

public class ItemPickup : MonoBehaviour
{
    public ItemType itemType;
    public int amount = 1;

    public void PickUp(Player player)
    {
        switch (itemType)
        {
            case ItemType.RawCacaoBeans:
                player.rawCacaoBeans += amount;
                break;
            case ItemType.CacaoPods:
                player.cacaoPods += amount; 
                break;
            case ItemType.GroundCacao:
                player.groundCacao += amount;
                break;
            case ItemType.Tablea:
                player.tablea += amount;
                break;
            case ItemType.Tsokolate:
                player.tsokolate += amount;
                break;
            case ItemType.PremiumChocolateBar:
                player.premiumChocolateBar += amount;
                break;
        }

        // Destroy the world item once collected
        Destroy(gameObject);
    }
}