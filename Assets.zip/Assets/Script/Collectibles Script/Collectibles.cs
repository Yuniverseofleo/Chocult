using UnityEngine;

public enum CacaoItemType
{
    RawCacaoBeans,      // Tier 1
    CacaoPods,    // Tier 2
    GroundCacao,        // Tier 3
    Tablea,             // Tier 4
    Tsokolate,          // Tier 5
    PremiumChocolateBar // Tier 6
}

public class Collectibles : MonoBehaviour
{
    [Header("Item Settings")]
    public CacaoItemType itemType; // Choose the tier/item type in the Inspector
    public int amount = 1;         // How many to give when collected

    private void OnTriggerEnter2D(Collider2D collision)
    {
        Player player = collision.GetComponent<Player>();

        if (player != null)
        {
            // Add the item to the correct player inventory variable based on selection
            switch (itemType)
            {
                case CacaoItemType.RawCacaoBeans:
                    player.rawCacaoBeans += amount;
                    break;
                case CacaoItemType.CacaoPods:
                    player.cacaoPods += amount;
                    break;
                case CacaoItemType.GroundCacao:
                    player.groundCacao += amount;
                    break;
                case CacaoItemType.Tablea:
                    player.tablea += amount;
                    break;
                case CacaoItemType.Tsokolate:
                    player.tsokolate += amount;
                    break;
                case CacaoItemType.PremiumChocolateBar:
                    player.premiumChocolateBar += amount;
                    break;
            }

            // Remove the collectible from the world
            Destroy(gameObject);
        }
    }
}