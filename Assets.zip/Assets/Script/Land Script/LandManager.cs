using System.Linq;
using UnityEngine;
using TMPro;

public class LandManager : MonoBehaviour
{
    public static LandManager Instance;

    public int money = 0;

    [SerializeField] private LandPlot[] plots;

    public TMP_Text moneyText;
    public TMP_Text messageText;

    private int highestUnlockedPlot = 1;

    private readonly int[] prices =
    {
        0, 500, 1000, 1500, 2000, 8300,
        9000, 10500, 11000, 14500, 20000, 25000
    };

    private void Awake()
    {
        Instance = this;
    }

    private void Start()
    {
        plots = plots
            .Where(plot => plot != null)
            .OrderBy(plot => plot.plotNumber)
            .ToArray();

        foreach (LandPlot plot in plots)
        {
            bool startingPlot = plot.plotNumber == 1;
            plot.SetUnlocked(startingPlot);
        }

        highestUnlockedPlot = 1;
        UpdateMoneyUI();
        ShowMessage("");
    }

    public int GetPrice(int plotNumber)
    {
        // Properly calculate index using plotNumber - 1
        int index = plotNumber - 1;

        if (index < 0 || index >= prices.Length)
            return -1;

        return prices[index];
    }

    public bool TryPurchase(LandPlot plot)
    {
        if (plot == null || plot.unlocked)
            return false;

        if (plot.plotNumber != highestUnlockedPlot + 1)
        {
            ShowMessage("Unlock the previous plot first!");
            return false;
        }

        int price = GetPrice(plot.plotNumber);

        if (price < 0 || money < price)
        {
            ShowMessage("Not enough money!");
            return false;
        }

        money -= price;
        plot.SetUnlocked(true);
        highestUnlockedPlot = plot.plotNumber;

        UpdateMoneyUI();
        ShowMessage("Plot " + plot.plotNumber + " unlocked with its facilities!");

        return true;
    }

    public void AddMoney(int amount)
    {
        if (amount <= 0)
            return;

        money += amount;
        UpdateMoneyUI();
    }

    public bool IsPositionOnUnlockedLand(Vector2 position)
    {
        foreach (LandPlot plot in plots)
        {
            if (plot != null &&
                plot.unlocked &&
                plot.landArea != null &&
                plot.landArea.OverlapPoint(position))
            {
                return true;
            }
        }

        return false;
    }

    public Vector3 RestrictMovement(
        Vector3 currentPosition,
        Vector3 targetPosition)
    {
        if (IsPositionOnUnlockedLand(targetPosition))
            return targetPosition;

        return currentPosition;
    }

    private void UpdateMoneyUI()
    {
        if (moneyText != null)
            moneyText.text = "₱" + money.ToString("N0");
    }

    public void ShowMessage(string message)
    {
        if (messageText != null)
            messageText.text = message;
    }
}