using UnityEngine;
using UnityEngine.InputSystem;

public class LandPlot : MonoBehaviour
{
    public int plotNumber = 1;
    public bool unlocked;

    public Collider2D landArea;
    public Transform interactionPoint;
    public GameObject lockedVisual;

    public float interactionDistance = 1.5f;

    [Header("Facilities on this Plot")]
    [Tooltip("Drag the facility GameObjects (e.g., Drying Rack, Grinder) belonging to this plot here.")]
    public GameObject[] plotFacilities;

    private Transform player;

    private void Start()
    {
        GameObject playerObject =
            GameObject.FindGameObjectWithTag("Player");

        if (playerObject != null)
            player = playerObject.transform;

        UpdateVisuals();
    }

    private void Update()
    {
        if (unlocked || player == null)
            return;

        Vector2 point = interactionPoint != null
            ? interactionPoint.position
            : transform.position;

        if (Vector2.Distance(player.position, point) >
            interactionDistance)
            return;

        if (Keyboard.current != null &&
            Keyboard.current.eKey.wasPressedThisFrame)
        {
            LandManager.Instance.TryPurchase(this);
        }
    }

    public void SetUnlocked(bool value)
    {
        unlocked = value;
        UpdateVisuals();

        // Automatically activate or deactivate facilities when the plot unlocks
        foreach (GameObject facility in plotFacilities)
        {
            if (facility != null)
            {
                facility.SetActive(unlocked);
            }
        }
    }

    private void UpdateVisuals()
    {
        if (lockedVisual != null)
            lockedVisual.SetActive(!unlocked);
    }
}