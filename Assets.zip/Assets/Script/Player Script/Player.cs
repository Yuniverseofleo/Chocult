using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.Rendering;

public class Player : MonoBehaviour
{
    [Header("Movement Settings")]
    public float speed = 5f;

    [Header("Planting & Farming Settings")]
    public GameObject seedPrefab;
    public Transform plantPoint;
    public KeyCode plantKey = KeyCode.P;
    public KeyCode depositPodKey = KeyCode.F;

    [Header("Inventory / Collected Items")]
    public int rawCacaoBeans = 0;
    public int cacaoPods = 0;
    public int groundCacao = 0;
    public int tablea = 0;
    public int tsokolate = 0;
    public int premiumChocolateBar = 0;

    private Rigidbody2D rb;
    private Vector2 input;
    private Greenhouse nearbyGreenhouse; // Tracks greenhouse the player is standing near

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    void Update()
    {
        // --- Movement Input ---
        input.x = Input.GetAxisRaw("Horizontal");
        input.y = Input.GetAxisRaw("Vertical");
        input.Normalize();

        // --- Planting Feature (Press P) ---
        if (Input.GetKeyDown(plantKey))
        {
            PlantSeed();
        }

        // --- Greenhouse Deposit Feature (Press F) ---
        if (Input.GetKeyDown(depositPodKey) && nearbyGreenhouse != null)
        {
            TryDepositPodToGreenhouse();
        }
    }

    private void FixedUpdate()
    {
        rb.linearVelocity = input * speed;
    }

    void PlantSeed()
    {
        if (seedPrefab != null && plantPoint != null)
        {
            Instantiate(seedPrefab, plantPoint.position, Quaternion.identity);
            Debug.Log("A seed has been planted!");
            // Optional: Add UI notification text trigger here
        }
        else
        {
            Debug.LogWarning("Seed Prefab or Plant Point is not assigned on the Player!");
        }
    }

    void TryDepositPodToGreenhouse()
    {
        if (cacaoPods > 0)
        {
            bool success = nearbyGreenhouse.StartFermentation(this);
            if (success)
            {
                cacaoPods--; // Deduct pod from inventory
                Debug.Log("Cacao pod placed in greenhouse! Beans are extracting and fermenting...");
            }
        }
        else
        {
            Debug.Log("You don't have any Cacao Pods in your inventory to deposit!");
        }
    }

    // Detect when player enters the Greenhouse trigger area
    private void OnTriggerEnter2D(Collider2D collision)
    {
        Greenhouse greenhouse = collision.GetComponent<Greenhouse>();
        if (greenhouse != null)
        {
            nearbyGreenhouse = greenhouse;
            Debug.Log("Press [F] to place Cacao Pod into the Greenhouse.");
        }
    }

    // Detect when player leaves the Greenhouse trigger area
    private void OnTriggerExit2D(Collider2D collision)
    {
        Greenhouse greenhouse = collision.GetComponent<Greenhouse>();
        if (greenhouse == null && collision.GetComponentInParent<Greenhouse>() != null)
        {
            greenhouse = collision.GetComponentInParent<Greenhouse>();
        }

        if (greenhouse == nearbyGreenhouse)
        {
            nearbyGreenhouse = null;
        }
    }
}