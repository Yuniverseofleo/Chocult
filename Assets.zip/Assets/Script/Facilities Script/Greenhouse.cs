using UnityEngine;
using TMPro; // Optional: If you use TextMeshPro for UI status text

public class Greenhouse : MonoBehaviour
{
    [Header("Fermentation Settings")]
    [Tooltip("Gameplay duration for fermentation in seconds (e.g., 180 seconds = 3 minutes)")]
    public float fermentationDuration = 180f;

    [Header("UI References (Optional)")]
    public TextMeshProUGUI statusText; // Assign world-space or screen text UI

    // States: 0 = Idle/Empty, 1 = Fermenting, 2 = Ready to Collect
    private int currentState = 0;
    private float currentTimer = 0f;
    private int extractedBeansBatch = 0;

    void Update()
    {
        if (currentState == 1) // Fermenting
        {
            currentTimer -= Time.deltaTime;

            // Format countdown display (e.g., "Fermenting: 2m 15s remaining")
            int minutes = Mathf.FloorToInt(currentTimer / 60f);
            int seconds = Mathf.FloorToInt(currentTimer % 60f);

            if (statusText != null)
            {
                statusText.text = $"Cacao is fermenting...\nTime remaining: {minutes:00}:{seconds:00}";
            }

            if (currentTimer <= 0f)
            {
                CompleteFermentation();
            }
        }
    }

    // Called by the Player script when pressing 'F' inside the trigger
    public bool StartFermentation(Player player)
    {
        if (currentState == 0) // Only accept if empty
        {
            currentState = 1;
            currentTimer = fermentationDuration;

            // Automatically extract beans from the pod based on your design
            extractedBeansBatch = Random.Range(10, 25); // Yield per pod batch

            if (statusText != null)
            {
                statusText.text = "Pod received! Extracting beans & starting fermentation...";
            }

            Debug.Log("Automatic Extraction: Pod broken open, beans sent to fermentation!");
            return true; // Successfully consumed pod
        }
        else if (currentState == 2)
        {
            Debug.Log("Greenhouse already has finished fermented cacao! Collect it first.");
            return false;
        }
        else
        {
            Debug.Log("Greenhouse is already busy fermenting!");
            return false;
        }
    }

    void CompleteFermentation()
    {
        currentState = 2; // Ready for collection
        if (statusText != null)
        {
            statusText.text = "Fermentation complete! Ready for drying. Press key or touch to collect.";
        }
        Debug.Log("Fermentation complete! Ready for drying stage.");
    }

    // Player can collect the ready fermented beans by walking into the greenhouse or pressing a key
    private void OnTriggerStay2D(Collider2D collision)
    {
        Player player = collision.GetComponent<Player>();
        if (player != null && currentState == 2)
        {
            // Transfer fermented beans back to player (or into a drying inventory slot)
            player.rawCacaoBeans += extractedBeansBatch;
            Debug.Log($"Collected {extractedBeansBatch} fermented/raw cacao beans! Transferring to drying process.");

            // Reset Greenhouse state
            currentState = 0;
            extractedBeansBatch = 0;
            if (statusText != null)
            {
                statusText.text = "Greenhouse Empty. Press [F] to place a Cacao Pod.";
            }
        }
    }
}